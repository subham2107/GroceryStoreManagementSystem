﻿using GroceryStoreMgmt.Controllers;
using GroceryStoreMgmt.Models;
using GroceryStoreMgmt.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NUnitTestGrocStoreMgmtProject
{

    public class GrocSellTest
    {

        GrocContext db;
        [SetUp]
        public void Setup()
        {
            var grocsells = new List<grocsell>
            {
                new grocsell{SellId =32,GrocId = 50, CustName ="Dummy1",  GrocQuantity=30,GrocBuyTime=new DateTime(2020-09-04)},
                new grocsell{SellId =40,GrocId = 21, CustName ="Dummy2",  GrocQuantity=70,GrocBuyTime=new DateTime(2020-08-04)},
                
            };
            var grocdata = grocsells.AsQueryable();
            var mockSet = new Mock<DbSet<grocsell>>();
            mockSet.As<IQueryable<grocsell>>().Setup(m => m.Provider).Returns(grocdata.Provider);
            mockSet.As<IQueryable<grocsell>>().Setup(m => m.Expression).Returns(grocdata.Expression);
            mockSet.As<IQueryable<grocsell>>().Setup(m => m.ElementType).Returns(grocdata.ElementType);
            mockSet.As<IQueryable<grocsell>>().Setup(m => m.GetEnumerator()).Returns(grocdata.GetEnumerator());
            var mockContext = new Mock<GrocContext>();
            mockContext.Setup(c => c.grocsells).Returns(mockSet.Object);
            db = mockContext.Object;
        }

       

        [Test]
        public void GrocItemGetTest()
        {

            var repo = new Mock<GrocSellRepo>(db);
            GrocSellController obj = new GrocSellController(repo.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }


        [Test]
        public void GetByIdPassTest()
        {
            var repo = new Mock<GrocSellRepo>(db);
            GrocSellController obj = new GrocSellController(repo.Object);
            var data = obj.Get(32);
            var okresult = data as ObjectResult;
            Assert.AreEqual(200, okresult.StatusCode);
        }
        [Test]
        public void GetByIdFailTest()
        {
            var repo = new Mock<GrocSellRepo>(db);
            GrocSellController obj = new GrocSellController(repo.Object);
            var data = obj.Get(987);
            var okresult = data as ObjectResult;
            Assert.AreEqual(400, okresult.StatusCode);
        }


    }
}