using GroceryStoreMgmt.Controllers;
using GroceryStoreMgmt.Models;
using GroceryStoreMgmt.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NUnitTestGrocStoreMgmtProject
{
    
    public class Tests
    {

        GrocContext db;
        [SetUp]
        public void Setup()
        {
            var grocitems = new List<grocitem>
            {
                new grocitem{GrocId = 50, GrocName ="Dummy1", GrocPrice=70.0, GrocQuantity=30,GrocTime=new DateTime(2020-09-04)},
                new grocitem{GrocId = 70, GrocName ="Dummy2", GrocPrice=80.0, GrocQuantity=30,GrocTime=new DateTime(2020-09-04)},
                new grocitem{GrocId = 8,GrocName = "Dummy3", GrocPrice = 150.0, GrocQuantity = 3, GrocTime = new DateTime(2020 - 09 - 04)}
        };
            var grocdata = grocitems.AsQueryable();
            var mockSet = new Mock<DbSet<grocitem>>();
            mockSet.As<IQueryable<grocitem>>().Setup(m => m.Provider).Returns(grocdata.Provider);
            mockSet.As<IQueryable<grocitem>>().Setup(m => m.Expression).Returns(grocdata.Expression);
            mockSet.As<IQueryable<grocitem>>().Setup(m => m.ElementType).Returns(grocdata.ElementType);
            mockSet.As<IQueryable<grocitem>>().Setup(m => m.GetEnumerator()).Returns(grocdata.GetEnumerator());
            var mockContext = new Mock<GrocContext>();
            mockContext.Setup(c => c.grocitems).Returns(mockSet.Object);
            db = mockContext.Object;
        }

        [Test]
        public void GrocItemPostTest()
        {

            var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            grocitem grocvalue = new grocitem { GrocId = 50, GrocName = "Dummy1", GrocPrice = 70.0, GrocQuantity = 30, GrocTime = new DateTime(2020 - 09 - 04) };
            var data = obj.Post(grocvalue);
            Assert.AreEqual("Congrats!Successfully added", data );
        }


        [Test]
        public void GrocItemGetTest()
        {

            var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }


        [Test]
        public void GetByIdPassTest()
        {
            var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            var data = obj.Get(70);
            var okresult = data as ObjectResult;

            Assert.AreEqual(200, okresult.StatusCode);
        }

        [Test]
        public void GetByIdFailTest()
        {
            var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            var data = obj.Get(963);
            var okresult = data as ObjectResult;

            Assert.AreEqual(400, okresult.StatusCode);
        }

        [Test]
        public void GrocItemPutTestPass()
        {
             var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            grocitem grocvalue = new grocitem
            {
                GrocId = 8,
                GrocName = "Dummy2",
                GrocPrice = 150.0,
                GrocQuantity = 3,
                GrocTime = new DateTime(2020 - 09 - 04)
            };

            var data = obj.Put(8, grocvalue);
       
            Assert.AreEqual("Congrats!Updated successfully",data);
        }
        [Test]
        public void GrocItemPutTestFail()
        {
            var repo = new Mock<GrocItemRepo>(db);
            GrocItemController obj = new GrocItemController(repo.Object);
            grocitem grocvalue = new grocitem
            {
                GrocId = 301,
                GrocName = "Dummy2",
                GrocPrice = 150.0,
                GrocQuantity = 3,
                GrocTime = new DateTime(2020 - 09 - 04)
            };
            var data = obj.Put(301, grocvalue);

            Assert.AreEqual("Enter a Id which already exists!", data);


        }

    }
}