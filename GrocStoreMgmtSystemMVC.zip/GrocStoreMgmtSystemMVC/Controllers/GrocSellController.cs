﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using GrocStoreMgmtSystemMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace GrocStoreMgmtSystemMVC.Controllers
{
    public class GrocSellController : Controller
    {
        Uri baseaddress = new Uri("https://localhost:44392/api");
        HttpClient client;
        public GrocSellController()
        {
            client = new HttpClient();
            client.BaseAddress = baseaddress;
        }
        public IActionResult Index()
        {
            List<grocsell> ls = new List<grocsell>();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/GrocSell").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<grocsell>>(data);
            }
            return View(ls);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(grocsell obj)
        {
            string data = JsonConvert.SerializeObject(obj);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/GrocSell", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult GetSell(int id)
        {
            List<grocsell> ls = new List<grocsell>();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/GrocSell/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<grocsell>>(data);
            }
            return View(ls);

        }


    }
}
